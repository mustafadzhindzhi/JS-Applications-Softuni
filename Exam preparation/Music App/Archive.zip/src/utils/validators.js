export const albumIsInvalid = (albumData) => {
    const requiredFields = [
        'name', 
        'imgUrl', 
        'price', 
        'releaseDate',
        'artist',
        'genre',
        'description'
    ];

    return requiredFields.some(x=>!albumData[x]) // за всеки един и виж дали имаш положителна стойност в албум нейм и това ще върне true, проверява за всички. нас ни интересува само едно което да е false.  ако едно е невалидно значи всички са невалидни 
}