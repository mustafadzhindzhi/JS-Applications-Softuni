//1
import {html, nothing} from '../../node_modules/lit-html/lit-html.js'
import * as albumService from '../services/albumService.js'
import { albumTemplate } from './templates/albumTemplate.js';

//2
const catalogTemplate = (albums,user) => html`<!--Catalog-->
<section id="catalogPage">
    <h1>All Albums</h1>

    ${albums.map(x=> albumTemplate(x, Boolean(user)))}
    
    ${albums.length == 0 
    ? html`<!--No albums in catalog-->
    <p>No Albums in Catalog!</p>`
    : nothing}

</section>
`;

//2.1
export const catalogView = (ctx) => {
    albumService.getAll()
    .then(albums => {
       ctx.render(catalogTemplate(albums, ctx.user));
    }) 
}