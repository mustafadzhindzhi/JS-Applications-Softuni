//1.
import {html} from '../../node_modules/lit-html/lit-html.js'

//2.2.
const guestLinks = html`<!--Only guest-->
<li><a href="/login">Login</a></li>
<li><a href="/register">Register</a></li>`;

//2.2
const userLinks = html`    <!--Only user-->
<li><a href="/create">Create Album</a></li>
<li><a href="/logout">Logout</a></li>`;

//2
const navigationTemplate = (user) => html` <nav>
<img src="./images/headphones.png">
<a href="/">Home</a>
<ul>
    <!--All user-->
    <li><a href="/catalog">Catalog</a></li>
    <li><a href="/search">Search</a></li>
    ${user
    ? userLinks
    : guestLinks}
</ul>
</nav>
`;

//2.1
export const navigationView = (ctx)=>{
    return navigationTemplate(ctx.user);
}