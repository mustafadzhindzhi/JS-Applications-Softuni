//1
import * as userService from '../services/userService.js';

//2
export const logoutView = (ctx) => {
    userService.logout()
    .then(() => {
        ctx.page.redirect('/')
    })
}