//1
import * as authService from '../services/authService.js'
//2
export const authMiddleWare = (ctx,next) =>{    
    ctx.user = authService.getUser();

    next();
}