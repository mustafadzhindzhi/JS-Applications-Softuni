//1
import {render} from '../../node_modules/lit-html/lit-html.js'
import { navigationView } from '../views/navigation.js';

//2.1
const headerElement = document.querySelector('.header-navigation')
//3.1
const contentElement = document.querySelector('#main-content')

//3.2
const renderContent = (templateResult) => {
    render(templateResult, contentElement);
};

//2
export const renderNavigationMiddleware = (ctx, next) => {
    render(navigationView(ctx),headerElement);
    next();
};

//3
export const renderContentMiddleware = (ctx, next) => {
    ctx.render = renderContent;

    next();
}