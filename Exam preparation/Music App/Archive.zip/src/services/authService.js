
//2.2
export const saveUser = (user) => {
    if(user.accessToken) {
    localStorage.setItem('user',JSON.stringify(user))
    }
};

//5.1
export const deleteUser = () => {
    localStorage.removeItem('user');
}
//2.3
export const getUser = () => {
    let serializedUser = localStorage.getItem('user');
    if(serializedUser) {
        let user = JSON.parse(serializedUser);
        return user;
    }
};

//5.2
export const getToken = () => {
    return getUser()?.accessToken;
}