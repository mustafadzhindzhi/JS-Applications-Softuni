//1
import * as request from './requester.js';

//2 
const baseUrl = 'http://localhost:3030/data/albums';

//2.1 това е когато правим каталога
export const getAll = () => request.get(`${baseUrl}?sortBy=_createdOn%20desc&distinct=name`);

//4 за детайлите
export const getOne = (albumId) => request.get(`${baseUrl}/${albumId}`);// това ни е по условие

//3 гогато започнем да създаваме криейт
export const create = (albumData) => request.post(baseUrl, albumData);

//5 това е за едита
export const edit = (albumId, albumData) => request.put(`${baseUrl}/${albumId}`, albumData);

//6 за делете
export const remove = (albumId) => request.del(`${baseUrl}/${albumId}`) 

//7 за search
export const search = (search) => {
    const query = encodeURIComponent(`name LIKE "${search}"`)
    return request.get(`${baseUrl}?where=${query}`)
}